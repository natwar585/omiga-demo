import { Component } from '@angular/core';

@Component({
  selector: 'app-requirment-news',
  templateUrl: './requirment-news.component.html',
  styleUrls: ['./requirment-news.component.scss']
})
export class RequirmentNewsComponent {

}
