import { Component } from '@angular/core';

@Component({
  selector: 'app-insider-news',
  templateUrl: './insider-news.component.html',
  styleUrls: ['./insider-news.component.scss']
})
export class InsiderNewsComponent {

}
